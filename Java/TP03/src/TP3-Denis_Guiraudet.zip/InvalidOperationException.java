public class InvalidOperationException extends IllegalStateException {

    public InvalidOperationException() {
        super();
    }

}

public class Ensemble_Tableau {

    public static void main(String[] args) {

        int[] tab1 =  {4, 5, 6, 6};
        int[] tab2 =  {2, 5, 3};

        stringTab(tab1);
        stringTab(tab2);

        //

        System.out.println("Reunion " + stringTab(reunion(tab1, tab2)));

        //

        System.out.println("Intersection " + stringTab(intersection(tab1, tab2)));

        //

        System.out.println("Difference " + stringTab(difference(tab1, tab2)));

        //

        System.out.println("Difference Symetrique " + stringTab(differenceSymetrique(tab1, tab2)));

    }

    private static String stringTab(int[] tab) {

        String str = "[";

        for (int i = 0; i < tab.length; i++) {

            str = str + tab[i];

            if (i == (tab.length - 1)) {

                return str + "]";

            }

            str = str + ", ";

        }

        return "ERROR";

    }

    private static int[] addElement(int[] oldTab, int elem) {

        int[] newTab = new int[oldTab.length + 1];

        for (int i = 0; i < oldTab.length; i++) {

            newTab[i] = oldTab[i];

        }

        newTab[newTab.length - 1] = elem;
        return newTab;

    }

    private static boolean recherche(int[] tab, int val) {

        for (int value: tab) {

            if (value == val) {

                return true;

            }

        }

        return false;

    }

    private static int rechercheIndex(int[] tab, int val) {

        for (int i = 0; i < tab.length; i++) {

            if (tab[i] == val) {

                return i;

            }

        }

        return tab.length; // ERREUR !

    }

    private static int[] reunion(int[] tab1, int[] tab2) { // A ∪ B

        int[] newTab = tab1.clone();

        for (int val: tab2) {

            newTab = addElement(newTab, val);

        }

        return newTab;

    }

    private static int[] intersection(int[] tab1, int[] tab2) { // A ∩ B

        int[] newTab = {};

        for (int val: tab1) {

            if (recherche(tab2, val)) {

                newTab = addElement(newTab, val);

            }

        }

        return newTab;

    }

    private static int[] difference(int[] tab1, int[] tab2) { // A \ B = A ∩ B c

        int[] newTab = {};

        for (int val1: tab1) {

            if (!recherche(tab2, val1)) {

                newTab = addElement(newTab, val1);

            }

        }

        return newTab;

    }

    private static int[] differenceSymetrique(int[] tab1, int[] tab2) { // A Δ B = (A ∩ B c) ∪ (A c ∩ B)

        int[] newTab = {};

        for (int val1: tab1) {

            if (!recherche(tab2, val1)) {

                newTab = addElement(newTab, val1);

            }

        }

        for (int val2: tab2) {

            if (!recherche(tab1, val2)) {

                newTab = addElement(newTab, val2);

            }

        }

        return newTab;

    }

}
